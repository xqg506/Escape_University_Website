<h1>Escape University</h1>

This project was produced for part 1 of the Eng1 module.
It is a 2D campus-themed adventure game built in Java using the LibGDX framework. In this game, the player is a university student and the goal is to catch the bus and escape campus within five minutes.


<b>Project website: https://team-6-eng.github.io/Escape_University_Website/index.html</b>



<br>
<br>
<br>

Assets which require attribution:

Seed packet icon by Freepik – https://www.flaticon.com/free-icon/packet_4769213
Available on Flaticon.com

Lil’ Scientist by Smithy Games - https://smithygames.itch.io/bouncy-scientist
Available on Itch.io

Bus by Max.Icons - https://www.flaticon.com/free-icon/bus_2706806
Available on Flaticon.com

Goose HONK! Sound - https://quicksounds.com/sound/22715/
Available on quicksounds.com

Smartphone icon by Special Flat - https://www.freepik.com/icon/smartphone_2482945
Available on Flaticon.com
