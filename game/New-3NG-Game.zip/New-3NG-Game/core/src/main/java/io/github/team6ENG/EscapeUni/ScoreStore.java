package io.github.team6ENG.EscapeUni;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;

public class ScoreStore {
    private static final String fileName = "Scores.csv";

    //Ensure the local file exists, or create it otherwise
    public static void Exists() {
        FileHandle f = Gdx.files.local(fileName);

        if (!f.exists()) {
            f.writeString("PlayerName, Score\n", false); //Header of the file
        }
    }
    
    //Appending an entry
    public static void addScore(String playerName, float score) {
        Exists();

        if (playerName.equals("")) {
            return;
        }
        else {
            String line = playerName + ":" + score;

            Gdx.files.local(fileName).writeString(line, true); //This time append is true
        }
    }

    public static String readAll() { 
        FileHandle f = Gdx.files.local(fileName);
        return f.exists() ? f.readString() : ""; //If exists is true, return f.readString() or otherwise return ""
    }

    public static float returnMaxScore() {
        FileHandle f = Gdx.files.local(fileName);
        if (!f.exists()) return 0;

        String[] lines = f.readString().split("\n"); //Splits the csv into each (name, score) line

        float maxScore = 0;

        //Skipping line 0, header
        for (int i = 1; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty()) continue;

            String[] parts = line.split(",");
            float score = Float.parseFloat(parts[1]); //Returns str Score = parts[1] as a float

            if (score > maxScore) {
                maxScore = score; 
            }
        }

        return maxScore;
    }
}
