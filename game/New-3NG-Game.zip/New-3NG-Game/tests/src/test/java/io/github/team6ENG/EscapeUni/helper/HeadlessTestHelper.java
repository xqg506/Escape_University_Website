package test.java.io.github.team6ENG.EscapeUni.helper;

import com.badlogic.gdx.Files;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.backends.headless.HeadlessApplication;
import com.badlogic.gdx.backends.headless.HeadlessApplicationConfiguration;
import com.badlogic.gdx.graphics.GL20;
import org.mockito.Mockito;

public class HeadlessTestHelper {
    
    private static boolean initialized = false;
    
    public static void initialize() {
        if (initialized) return;
        
        // Mocking OpenGL
        Gdx.gl = Mockito.mock(GL20.class);
        Gdx.gl20 = Gdx.gl;

        Gdx.files = Mockito.mock(Files.class);
        
        // Create headless application
        HeadlessApplicationConfiguration config = new HeadlessApplicationConfiguration();
        new HeadlessApplication(new HeadlessAppListener(), config);
        
        // Wait for initialization
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        initialized = true;
    }
    
    static class HeadlessAppListener extends com.badlogic.gdx.ApplicationAdapter {
        @Override
        public void create() {
            // Empty - just needed for headless
        }
    }
}