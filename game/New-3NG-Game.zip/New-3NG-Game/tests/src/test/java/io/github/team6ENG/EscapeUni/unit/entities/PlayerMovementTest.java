package test.java.io.github.team6ENG.EscapeUni.unit.entities;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

public class PlayerMovementTest extends PlayerTestBase {
    
    @BeforeEach
    public void setUp() {
        super.setUpBase();
    }

    /**
     * Verifies that the player character correctly updates its position and state 
     * when the 'W' movement key is pressed and no obstacles are present.
     * * <p>This test ensures that:
     * <ul>
     * <li>The movement flag is set to true.</li>
     * <li>The orientation is updated to 'Up'.</li>
     * <li>The vertical coordinate increases over time.</li>
     * </ul> 
     */
    @Test
    @DisplayName("6.1 - MovementW - Player should move upward when 'W' is pressed in an open area")
    public void testPlayerMovesUpWhenWKeyPressed() {
        // Arrange
        // Simulate user pressing the 'W' key
        setInputKeyPressed(Input.Keys.W, true);
        when(mockWallsLayer.getCell(anyInt(), anyInt())).thenReturn(null); // No walls
        
        float initialY = player.sprite.getY();
        
        // Act
        // Execute input handling for a single frame
        player.handleInput(0.016f, 1.0f); // 60 FPS delta
        
        // Assert
        // Validate that the internal state and sprite position updated correctly
        assertTrue(player.isMoving, "Player should be moving");
        assertTrue(player.isFacingUp, "Player should be facing up" );
        assertTrue(player.sprite.getY() > initialY, "Player Y should increase");
    }
    
    /**
     * Verifies that the player character correctly updates its position and state 
     * when the 'S' movement key is pressed and no obstacles are present.
     * * <p>This test ensures that:
     * <ul>
     * <li>The movement flag is set to true.</li>
     * <li>The orientation is updated to 'Down'.</li>
     * <li>The vertical coordinate decreases over time.</li>
     * </ul>  
     */
    @Test
    @DisplayName("6.2 - MovementS - Player should move downward when 'S' is pressed in an open area")
    public void testPlayerMovesDownWhenSKeyPressed() {
        // Arrange
        // Simulate player pressing the 'S' key
        setInputKeyPressed(Input.Keys.S, true);
        when(mockWallsLayer.getCell(anyInt(), anyInt())).thenReturn(null);
        
        // Move player to the middle so they have room to go down
        player.sprite.setPosition(100, 100); 
        float initialY = player.sprite.getY();
        
        // Act
        // Execute input handling for a single frame
        player.handleInput(0.016f, 1.0f);
        
        // Assert
        // Validate that the internal state and sprite position updated correctly
        assertTrue(player.isMoving, "Player should be flagged as moving");
        assertFalse(player.isFacingUp, "Player should be facing down");
        assertTrue(player.sprite.getY() < initialY, "Y should have decreased");
    }
    
    /**
     * Verifies that the player cannot move through tile cells which contain walls.
     * * <p> This test ensures that:
     * <ul>
     * <li>The player moves towards the wall</li>
     * <li>There is no difference in initial X position and final X position</li>
     * </ul>
     */
    @Test
    @DisplayName("6.3 - Walls - Player should not move when moving into a wall")
    public void testPlayerCannotMoveThroughWalls() {
        // Arrange
        // Simulate player pressing the 'D' key
        setInputKeyPressed(Input.Keys.D, true);
        TiledMapTileLayer.Cell wallCell = createMockCell(WALL_TILE_ID);
        when(mockWallsLayer.getCell(anyInt(), anyInt())).thenReturn(wallCell);
        
        float initialX = player.sprite.getX();
        
        // Act
        // Execute input handling for a single frame
        player.handleInput(0.016f, 1.0f);
        
        // Assert
        // Validate that the player does not move, due to a collision with the cell containing the wall.
        assertEquals(initialX, player.sprite.getX(), 0.001f, "Player should not move through walls");
        verify(mockWallsLayer).getCell(anyInt(), anyInt());
    }
    
    /**
     * Verifies that when in a cell containing water the player's speed is halved when moving.
     * * <p>This test ensures that:
     * <ul>
     * <li>The player's movement speed is halved when in water.</li>
     * </ul>
     */
    @Test
    @DisplayName("6.4 - WaterSpeed - Player should move at half speed when in water")
    public void testPlayerSpeedHalvedInWater() {
        // Simulate the player pressing the 'D' key in a 
        setInputKeyPressed(Input.Keys.D, true);
        TiledMapTileLayer.Cell waterCell = createMockCell(WATER_TILE_ID);
        
        // --- WATER MOVEMENT ---
        when(mockWallsLayer.getCell(anyInt(), anyInt())).thenReturn(waterCell);
        
        // Call once to trigger the "inWater" flag (moves 1.2, but sets flag to true)
        player.handleInput(0.016f, 1.0f); 
        
        float startX = player.sprite.getX();
        // Call again - now it uses inWater = true to calculate speed (moves 0.6)
        player.handleInput(0.016f, 1.0f);
        float waterMovement = player.sprite.getX() - startX;

        // --- NORMAL MOVEMENT ---
        when(mockWallsLayer.getCell(anyInt(), anyInt())).thenReturn(null);
        
        // Call once to clear the "inWater" flag (moves 0.6, but sets flag to false)
        player.handleInput(0.016f, 1.0f); 
        
        startX = player.sprite.getX();
        // Call again - now it uses inWater = false (moves 1.2)
        player.handleInput(0.016f, 1.0f);
        float normalMovement = player.sprite.getX() - startX;

        // Assert
        assertEquals(normalMovement / 2, waterMovement, 0.01f, "Water speed should be half of normal speed");
    }
    
    /**
     * Verifies that when on a map boundary, the player cannot move past the boundary.
     * * <p>This test ensures that:
     * <ul>
     * <li>The player's position stays the same when {@Link #keepPlayerInBounds()} is called</li>
     * </ul>
     */
    @Test
    @DisplayName("6.5 - Bounds - Player should stay within bounds")
    public void testPlayerStaysWithinBounds() {
        // Arrange - Place player at right edge
        float worldWidth = 20 * TILE_DIMENSIONS; // 20 tiles * 16px
        player.sprite.setX(worldWidth - player.sprite.getWidth()); // 10px beyond
        
        // Act
        player.keepPlayerInBounds();
        
        // Assert
        // Validate that there is no difference in X position after the player has been moved to the correct position.
        assertEquals(worldWidth - player.sprite.getWidth(), player.sprite.getX(), 0.001f, "Player should be clamped to boundary");
    }
    
    /**
     * Verifies that the player cannot move past the set barrier to enter langwith without 
     * collecting the key card.
     * * <p>This test ensures that:
     * <ul>
     * <li>The player's position stays the same when they should be blocked from moving</li>
     * <li>The player's position changes when they are allowed to move.
     * </ul>
     */
    @Test
    @DisplayName("6.6 - LangwithBarrier - Langwith barrier should stop the player")
    public void testLangwithBarrierBlocksUntilEntered() {
        // Arrange
        setInputKeyPressed(Input.Keys.W, true);
        TiledMapTileLayer.Cell barrierCell = createMockCell(LANGWITH_BARRIER_ID);
        when(mockWallsLayer.getCell(anyInt(), anyInt())).thenReturn(barrierCell);
        
        float initialY = player.sprite.getY();
        
        // Act - Try to move before entering Langwith
        player.handleInput(0.016f, 1.0f);
        
        // Assert - Should be blocked
        assertEquals(initialY, player.sprite.getY(), 0.001f, "Should not pass barrier before entering Langwith");
        
        // Arrange - Now player has entered Langwith
        player.hasEnteredLangwith = true;
        player.sprite.setY(initialY); // Reset position
        
        // Act - Try to move after entering
        player.handleInput(0.016f, 1.0f);
        
        // Assert - Should pass through
        assertTrue(player.sprite.getY() > initialY, "Should pass barrier after entering Langwith");
    }
}
