package test.java.io.github.team6ENG.EscapeUni.unit.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.tiles.StaticTiledMapTile;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import io.github.team6ENG.EscapeUni.AudioManager;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Player;
import test.java.io.github.team6ENG.EscapeUni.helper.HeadlessTestHelper;

import com.badlogic.gdx.graphics.g2d.TextureRegion;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.quality.Strictness;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PlayerTestBase {
    
    protected Player player;
    
    @Mock protected Main mockGame;
    @Mock protected AudioManager mockAudioManager;
    @Mock protected TiledMap mockTiledMap;
    protected TiledMapTileLayer mockWallsLayer;
    @Mock protected FitViewport mockViewport; 
    
    // Constants
    protected static final int TILE_DIMENSIONS = 16;
    protected static final int MAP_WIDTH = 50;
    protected static final int MAP_HEIGHT = 50;
    protected static final int WALL_TILE_ID = 1;
    protected static final int LANGWITH_BARRIER_ID = 2;
    protected static final int WATER_TILE_ID = 3;
    
    @BeforeEach
    public void setUpBase() {
        HeadlessTestHelper.initialize();
        
        mockViewport = mock(FitViewport.class);
        
        mockGame.viewport = mockViewport; 
        mockGame.activeSpritePath = "../assets/sprites/maleSprite.png";

        mockWallsLayer = mock(TiledMapTileLayer.class);

        lenient().when(mockWallsLayer.getWidth()).thenReturn(MAP_WIDTH);
        lenient().when(mockWallsLayer.getHeight()).thenReturn(MAP_HEIGHT);

        lenient().when(mockViewport.getWorldHeight()).thenReturn((float)MAP_HEIGHT);
        lenient().when(mockViewport.getWorldWidth()).thenReturn((float)MAP_WIDTH);
        
        player = new Player(mockGame, mockAudioManager, LANGWITH_BARRIER_ID, WATER_TILE_ID);
        
        player.setWallsLayer(mockWallsLayer);
        player.setMapWallsID(WALL_TILE_ID);
        player.setTileDimensions(TILE_DIMENSIONS);

        Gdx.input = mock(Input.class, withSettings().strictness(Strictness.LENIENT));

    }
    
    protected TiledMapTileLayer.Cell createMockCell(int tileId) {
        TiledMapTileLayer.Cell cell = mock(TiledMapTileLayer.Cell.class);
        com.badlogic.gdx.maps.tiled.TiledMapTile tile = mock(com.badlogic.gdx.maps.tiled.TiledMapTile.class);
        when(tile.getId()).thenReturn(tileId);
        when(cell.getTile()).thenReturn(tile);
        return cell;
    }
    
    protected void setInputKeyPressed(int key, boolean pressed) {
        // 1. Set the default for ANY key to false
    lenient().when(Gdx.input.isKeyPressed(anyInt())).thenReturn(false);
    
    // 2. Set the specific key you care about to the desired state
    lenient().when(Gdx.input.isKeyPressed(key)).thenReturn(pressed);
    }
}