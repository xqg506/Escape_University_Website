package test.java.io.github.team6ENG.EscapeUni.unit.entities;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SimpleTest {
    @Test
    public void testAddition() {
        int result = 2+2;
        assertEquals(4, result, "2+2 should equal 4");
    }

    @Test
    public void testString() {
        // String manipulation test
        String greeting = "Hello";
        String name = "World";
        String message = greeting + " " + name + "!";
        assertEquals("Hello World!", message, "Strings should concatenate correctly");
    }
    
    @Test
    public void testBoolean() {
        // Boolean logic test
        assertTrue(5 > 3, "5 should be greater than 3");
        assertFalse(2 > 5, "2 should not be greater than 5");
    }
}
